var class_mini_j_s_o_n_1_1_json =
[
    [ "Deserialize", "class_mini_j_s_o_n_1_1_json.html#acc0450803591edb84319322b117dfa56", null ],
    [ "Serialize", "class_mini_j_s_o_n_1_1_json.html#ae837bde991d51efee0db55e1c377eb2f", null ]
];