var namespaces =
[
    [ "IQU", "namespace_i_q_u.html", "namespace_i_q_u" ]
];