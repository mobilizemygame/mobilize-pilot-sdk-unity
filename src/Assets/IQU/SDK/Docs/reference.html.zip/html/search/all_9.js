var searchData=
[
  ['sdk',['SDK',['../namespace_i_q_u_1_1_s_d_k.html#a906ded21551e7190286b31b1a675fc51af20e3c5e54c0ab3d375d660b3f896f6a',1,'IQU::SDK']]],
  ['sdktype',['SdkType',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a919d963d318816ebea70ceaa301b1906',1,'IQU::SDK::IQUSDK']]],
  ['sdkversion',['SdkVersion',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#ae7959bb153189f86ae26c5abf2508793',1,'IQU::SDK::IQUSDK']]],
  ['secretkey',['secretKey',['../class_i_q_u_s_d_k_component.html#a20b503182ae5f9a35ec31d9849722bb8',1,'IQUSDKComponent']]],
  ['serveravailable',['ServerAvailable',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#af6be74f78896d70265e641f4216172ee',1,'IQU::SDK::IQUSDK']]],
  ['setcustomid',['SetCustomId',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#afedb090ecb620b388f07abd518a806bd',1,'IQU::SDK::IQUSDK']]],
  ['setfacebookid',['SetFacebookId',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a1ac3bddf94de94e3c6a89ae6fffda6f4',1,'IQU::SDK::IQUSDK']]],
  ['setgoogleplusid',['SetGooglePlusId',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a8ab27bee8643ddd34d4d7258344448e2',1,'IQU::SDK::IQUSDK']]],
  ['settwitterid',['SetTwitterId',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a06d4ca4732373e6058f4dc45b60a6e8e',1,'IQU::SDK::IQUSDK']]],
  ['simulateoffline',['SimulateOffline',['../namespace_i_q_u_1_1_s_d_k.html#ad70846cdf90ecf0a21c363f40ecbd64caebcad7c4a93c01b7dedaebc167af0dd5',1,'IQU::SDK']]],
  ['simulateserver',['SimulateServer',['../namespace_i_q_u_1_1_s_d_k.html#ad70846cdf90ecf0a21c363f40ecbd64ca0ef4eb022bef787c84559aaf577302b5',1,'IQU::SDK']]],
  ['start',['Start',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a8ed650aefec73a21fcecd71af6efec13',1,'IQU.SDK.IQUSDK.Start(string anApiKey, string aSecretKey)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a43c71c115757da10d045c62841152306',1,'IQU.SDK.IQUSDK.Start(string anApiKey, string aSecretKey, bool aPayable)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a7d49c320bb10ea2ae698bf77dc745de4',1,'IQU.SDK.IQUSDK.Start(string anApiKey, string aSecretKey, string aCustomId)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#ab501684245b516099f66ccb881b67408',1,'IQU.SDK.IQUSDK.Start(string anApiKey, string aSecretKey, string aCustomId, bool aPayable)']]]
];
