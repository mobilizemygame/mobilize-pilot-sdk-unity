var searchData=
[
  ['trackcountry',['TrackCountry',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a824cf5941fd0dcf962b07f864a925699',1,'IQU::SDK::IQUSDK']]],
  ['trackitempurchase',['TrackItemPurchase',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a4b5d812ad6150150a45365a7fb51d43e',1,'IQU.SDK.IQUSDK.TrackItemPurchase(string aName)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a276b6a4055e66a72c220ff218f6cb548',1,'IQU.SDK.IQUSDK.TrackItemPurchase(string aName, float aVirtualCurrencyAmount)']]],
  ['trackmarketing',['TrackMarketing',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#ab1013e48dc4440f51d66c49922f75855',1,'IQU::SDK::IQUSDK']]],
  ['trackmilestone',['TrackMilestone',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a725f0b3bb7772987be3bdf08d07098cf',1,'IQU::SDK::IQUSDK']]],
  ['trackrevenue',['TrackRevenue',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a40af9bb9dd8d39fb92ce47adbfd04ec3',1,'IQU.SDK.IQUSDK.TrackRevenue(float anAmount, string aCurrency, string aReward)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a41dd88f4b889814f5ed3503afbb765b3',1,'IQU.SDK.IQUSDK.TrackRevenue(float anAmount, string aCurrency)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a37f2822e3362011d97ca29c9d0447cca',1,'IQU.SDK.IQUSDK.TrackRevenue(float anAmount, string aCurrency, float aVirtualCurrencyAmount, string aReward)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a4388cc85272e9991122e4137bf7c7f9d',1,'IQU.SDK.IQUSDK.TrackRevenue(float anAmount, string aCurrency, float aVirtualCurrencyAmount)']]],
  ['tracktutorial',['TrackTutorial',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#adcfb59621cae4ec3078a4666de0f9193',1,'IQU::SDK::IQUSDK']]],
  ['trackuserattribute',['TrackUserAttribute',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a06b84bed2cc20b16c7bee9f7d520cdd9',1,'IQU::SDK::IQUSDK']]]
];
