var searchData=
[
  ['getid',['GetId',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#adc7040f699c55ae62bd23179a742b52a',1,'IQU::SDK::IQUSDK']]],
  ['googleplus',['GooglePlus',['../namespace_i_q_u_1_1_s_d_k.html#a906ded21551e7190286b31b1a675fc51a3d3d552218a9e0a939f88129ffba76e5',1,'IQU::SDK']]]
];
