var searchData=
[
  ['setcustomid',['SetCustomId',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#afedb090ecb620b388f07abd518a806bd',1,'IQU::SDK::IQUSDK']]],
  ['setfacebookid',['SetFacebookId',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a1ac3bddf94de94e3c6a89ae6fffda6f4',1,'IQU::SDK::IQUSDK']]],
  ['setgoogleplusid',['SetGooglePlusId',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a8ab27bee8643ddd34d4d7258344448e2',1,'IQU::SDK::IQUSDK']]],
  ['settwitterid',['SetTwitterId',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a06d4ca4732373e6058f4dc45b60a6e8e',1,'IQU::SDK::IQUSDK']]],
  ['start',['Start',['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a8ed650aefec73a21fcecd71af6efec13',1,'IQU.SDK.IQUSDK.Start(string anApiKey, string aSecretKey)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a43c71c115757da10d045c62841152306',1,'IQU.SDK.IQUSDK.Start(string anApiKey, string aSecretKey, bool aPayable)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#a7d49c320bb10ea2ae698bf77dc745de4',1,'IQU.SDK.IQUSDK.Start(string anApiKey, string aSecretKey, string aCustomId)'],['../class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html#ab501684245b516099f66ccb881b67408',1,'IQU.SDK.IQUSDK.Start(string anApiKey, string aSecretKey, string aCustomId, bool aPayable)']]]
];
