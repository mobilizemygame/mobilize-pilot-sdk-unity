var hierarchy =
[
    [ "IQU.SDK.IQUSDK", "class_i_q_u_1_1_s_d_k_1_1_i_q_u_s_d_k.html", null ],
    [ "MonoBehaviour", null, [
      [ "IQUSDKComponent", "class_i_q_u_s_d_k_component.html", null ]
    ] ]
];